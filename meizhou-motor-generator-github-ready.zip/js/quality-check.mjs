import { Box3 } from "three";
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  ASSEMBLY_LABELS,
  ASSEMBLY_NAMES,
  D,
  MODEL_BOUNDS,
  airGapMeasurement,
} from "./contracts.js";
import { createGeneratorModel } from "./generator-model.js";
import { RotorExploder } from "../vendor/explode.js";
import { auditMeshData, auditTriangleSoup } from "../vendor/geometry-quality-kit/mesh-topology-audit.js";
import { auditGeometry } from "../vendor/geometry-quality-kit/geometry-audit.js";

const here = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(here, "..");
const model = createGeneratorModel();
const failures = [];
const warnings = [];

function check(condition, message, details = null) {
  if (!condition) failures.push(details ? `${message}: ${JSON.stringify(details)}` : message);
}

function close(actual, expected, tolerance = 1e-6) {
  return Number.isFinite(actual) && Math.abs(actual - expected) <= tolerance;
}

const actualNames = model.children.map((child) => child.name);
check(
  actualNames.length === ASSEMBLY_NAMES.length &&
    new Set(actualNames).size === actualNames.length &&
    ASSEMBLY_NAMES.every((name) => actualNames.includes(name)),
  "顶层装配名称缺失、重复或顺序不符",
  actualNames,
);

const partAudit = [];
for (const assembly of model.children) {
  const parts = assembly.userData.auditParts ?? [];
  check(parts.length > 0, `${assembly.name} 缺少语义零件审计数据`);
  check(
    parts.length === assembly.userData.localParts?.length,
    `${assembly.name} 的 auditParts 与 localParts 数量不一致`,
  );
  for (const part of parts) {
    const report = auditMeshData(part.meshData);
    partAudit.push({ assembly: assembly.name, name: part.name, ok: report.ok, issues: report.issues });
    check(report.ok, `零件拓扑审计失败 ${part.name}`, report.issues);
  }
}

const emittedAudit = { meshes: 0, triangles: 0, failures: [] };
model.traverse((object) => {
  if (!object.isMesh) return;
  emittedAudit.meshes++;
  const geometry = object.geometry;
  const positions = geometry.getAttribute("position");
  const normals = geometry.getAttribute("normal");
  const report = auditTriangleSoup({
    positions: Array.from(positions.array),
    normals: Array.from(normals.array),
  });
  emittedAudit.triangles += report.triangles;
  if (!report.ok) emittedAudit.failures.push({ name: object.name, issues: report.issues });
  check(report.ok, `发射网格审计失败 ${object.name}`, report.issues);
});
check(emittedAudit.meshes > 0 && emittedAudit.triangles > 0, "模型没有可审计网格");

const geometryReport = auditGeometry(model, {
  maxTriangles: 600000,
  top: 100,
  clashCellSize: 0.4,
});
check(!geometryReport.truncated, "几何总审计被三角面上限截断");
check(geometryReport.defects.length === 0, "几何总审计发现退化面或法线缺陷", geometryReport.defects);
check(geometryReport.noMaterial.length === 0, "存在缺少材质的网格", geometryReport.noMaterial);
check(geometryReport.zfight.length === 0, "存在共面闪烁风险", geometryReport.zfight);
check(geometryReport.clash.length === 0, "存在实体穿模", geometryReport.clash);

const gap = airGapMeasurement();
check(close(gap, D.statorCoreInner - D.rotorMagnetOuter), "气隙计算不一致");
check(gap > 0.02 && gap < 0.08, "气隙超出速成模型合理范围", { gap });
check(
  D.rotorMagnetOuter < D.statorCoreInner &&
    D.rotorMagnetInner > 0 &&
    D.statorCoreInner > D.rotorMagnetInner,
  "定转子径向尺寸关系错误",
);

const byName = Object.fromEntries(model.children.map((assembly) => [assembly.name, assembly]));
const bounds = (name) => new Box3().setFromObject(byName[name]);
const boundsByName = Object.fromEntries(
  ASSEMBLY_NAMES.map((name) => [name, bounds(name)]),
);

function authoringZRange(assemblyName, localPrefix) {
  const parts = byName[assemblyName].userData.auditParts.filter((part) =>
    part.name.startsWith(`${model.name}.${assemblyName}.${localPrefix}`),
  );
  check(parts.length > 0, `缺少支撑审计零件 ${assemblyName}.${localPrefix}`);
  const zValues = parts.flatMap((part) => part.meshData.verts.map((vertex) => vertex[2]));
  return { min: Math.min(...zValues), max: Math.max(...zValues) };
}

function authoringZRangeExact(assemblyName, localName) {
  const part = byName[assemblyName].userData.auditParts.find(
    (entry) => entry.name === `${model.name}.${assemblyName}.${localName}`,
  );
  check(Boolean(part), `缺少审计零件 ${assemblyName}.${localName}`);
  if (!part) return { min: Number.NaN, max: Number.NaN };
  const zValues = part.meshData.verts.map((vertex) => vertex[2]);
  return { min: Math.min(...zValues), max: Math.max(...zValues) };
}

function supportGap(assemblyName, localPrefix, supportAssembly, supportPrefix) {
  const upper = authoringZRange(assemblyName, localPrefix);
  const lower = authoringZRange(supportAssembly, supportPrefix);
  return upper.min - lower.max;
}

const supportGaps = {
  anchorSeatToLowerFrameFoot: supportGap(
    "lowerFrameAssembly",
    "supportFoot_",
    "foundationAssembly",
    "anchorSeat_",
  ),
  lowerFrameToStatorBracket: supportGap(
    "statorHousingAssembly",
    "baseBracket_",
    "lowerFrameAssembly",
    "bearingRing",
  ),
  statorToUpperFrameRing: supportGap(
    "upperFrameAssembly",
    "upperRing",
    "statorHousingAssembly",
    "upperBand",
  ),
  lowerPlinthToCoolerPedestal: supportGap(
    "coolingAssembly",
    "coolerPedestal_",
    "foundationAssembly",
    "lowerPlinth",
  ),
  lowerPlinthToTerminalSupport: supportGap(
    "excitationAndLeads",
    "terminalSupport_",
    "foundationAssembly",
    "lowerPlinth",
  ),
};
for (const [name, value] of Object.entries(supportGaps)) {
  check(Math.abs(value) <= 1e-5, `支撑关系存在竖向间隙 ${name}`, { gap: value });
}

check(
  byName.statorHousingAssembly.userData.counts?.inspectionWindows === D.inspectionWindows &&
    byName.statorHousingAssembly.userData.counts?.windowOpeningsThroughWall === true,
  "检修窗数量或贯通标记错误",
);
check(
  byName.statorHousingAssembly.userData.localParts.filter((part) =>
    part.name.startsWith("windowPillar_"),
  ).length === D.inspectionWindows,
  "检修窗立柱数量错误",
);
check(
  byName.statorActiveAssembly.userData.counts?.endWindingGroups === D.modeledEndWindingGroups,
  "端部绕组示意组数错误",
);
check(
  byName.foundationAssembly.userData.counts?.anchorSeats === D.lowerFrameArms &&
    byName.foundationAssembly.userData.localParts.filter((part) =>
      part.name.startsWith("anchorSeat_"),
    ).length === D.lowerFrameArms,
  "锚固座实际数量与下机架支臂数不一致",
);
check(
  byName.lowerFrameAssembly.userData.localParts.filter((part) =>
    part.name.startsWith("radialArm_"),
  ).length === D.lowerFrameArms &&
    byName.lowerFrameAssembly.userData.localParts.filter((part) =>
      part.name.startsWith("supportFoot_"),
    ).length === D.lowerFrameArms,
  "下机架 10 支臂或支撑脚数量错误",
);
check(
  byName.rotorAssembly.userData.localParts.filter((part) =>
    part.name.startsWith("poleBody_"),
  ).length === D.poleCount &&
    D.poleCount === D.polePairs * 2,
  "磁极数量与极对数关系错误",
);
const countParts = (assemblyName, prefix) =>
  byName[assemblyName].userData.localParts.filter((part) =>
    part.name.startsWith(prefix),
  ).length;
check(
  countParts("rotorAssembly", "poleBody_") === D.poleCount &&
    countParts("rotorAssembly", "poleShoe_") === D.poleCount &&
    countParts("rotorAssembly", "poleWindingLower_") === D.poleCount &&
    countParts("rotorAssembly", "poleWindingUpper_") === D.poleCount,
  "转子极身、极靴或上下极绕组数量错误",
);

const rotor = byName.rotorAssembly;
const rotorSupport = rotor.getObjectByName("rotorSupportAssembly");
const rotorYoke = rotor.getObjectByName("rotorYokeAssembly");
const rotorPoles = rotor.getObjectByName("rotorPoleAssembly");
const rotorGroups = [rotorSupport, rotorYoke, rotorPoles];
check(
  rotorGroups.every((group) => group?.parent === rotor) &&
    new Set(rotorGroups.map((group) => group?.name)).size === 3,
  "转子支架、磁轭、磁极组不是 rotorAssembly 下的并列子装配",
);
check(rotorSupport?.userData.localParts.length > 0, "转子支架缺少语义零件");
check(rotorYoke?.userData.localParts.length === D.rotorRimSegments, "转子磁轭层数错误");
check(rotorPoles?.children.length === D.poleCount, "rotorPoleAssembly 下磁极组数量错误");

const poleGroups = [];
for (let index = 1; index <= D.poleCount; index++) {
  const name = `pole_${String(index).padStart(2, "0")}`;
  const pole = rotorPoles?.getObjectByName(name);
  poleGroups.push(pole);
  check(Boolean(pole) && pole.parent === rotorPoles, `缺少转子磁极 ${name}`);
  check(pole?.children.filter((child) => child.isMesh).length === 4, `${name} 零件数量错误`);
  for (const mesh of pole?.children ?? []) {
    check(mesh.userData.pickRoot === pole, `${mesh.name} 未归并到所属磁极`);
    check(
      mesh.userData.highlightRoot === rotorPoles,
      `${mesh.name} 未归并到转子磁极组高亮`,
    );
  }
}
for (const mesh of rotorSupport?.children ?? []) {
  check(mesh.userData.pickRoot === rotorSupport, `${mesh.name} 未归并到转子支架`);
}
for (const mesh of rotorYoke?.children ?? []) {
  check(mesh.userData.pickRoot === rotorYoke, `${mesh.name} 未归并到转子磁轭`);
}

const materialOwners = new Map();
for (const group of rotorGroups) {
  group?.traverse((object) => {
    if (!object.isMesh) return;
    for (const material of [].concat(object.material)) {
      const owner = materialOwners.get(material);
      check(!owner || owner === group, `${object.name} 与其他转子子装配共享材质`);
      materialOwners.set(material, group);
    }
  });
}

rotorSupport.visible = false;
check(!rotorSupport.visible && rotorYoke.visible && rotorPoles.visible, "隐藏支架连带隐藏其他结构");
rotorSupport.visible = true;
rotorYoke.visible = false;
check(rotorSupport.visible && !rotorYoke.visible && rotorPoles.visible, "隐藏磁轭连带隐藏其他结构");
rotorYoke.visible = true;
rotorPoles.visible = false;
check(rotorSupport.visible && rotorYoke.visible && !rotorPoles.visible, "隐藏磁极连带隐藏其他结构");
rotorPoles.visible = true;

const rotorExploder = new RotorExploder(rotor);
const supportHome = {
  position: rotorSupport.position.clone(),
  quaternion: rotorSupport.quaternion.clone(),
  scale: rotorSupport.scale.clone(),
};
const yokeHome = {
  position: rotorYoke.position.clone(),
  quaternion: rotorYoke.quaternion.clone(),
  scale: rotorYoke.scale.clone(),
};
const poleHomes = poleGroups.map((pole) => ({
  pole,
  position: pole.position.clone(),
  quaternion: pole.quaternion.clone(),
  scale: pole.scale.clone(),
}));
rotorExploder.set(1);
check(
  poleGroups.every((pole) => pole.position.length() > 1.1),
  "转子专项分解时磁极未先沿径向展开",
);
check(rotorYoke.scale.x > 1.13 && rotorYoke.scale.z > 1.13, "磁轭未在磁极后径向分层");
check(
  rotorSupport.position.equals(supportHome.position),
  "转子专项分解时支架未留在主轴附近",
);
rotorExploder.set(0);
check(
  rotorSupport.position.equals(supportHome.position) &&
    rotorSupport.quaternion.equals(supportHome.quaternion) &&
    rotorSupport.scale.equals(supportHome.scale) &&
    rotorYoke.position.equals(yokeHome.position) &&
    rotorYoke.quaternion.equals(yokeHome.quaternion) &&
    rotorYoke.scale.equals(yokeHome.scale),
  "转子专项分解归零后未精确恢复支架或磁轭",
);
check(
  poleHomes.every(
    ({ pole, position, quaternion, scale }) =>
      pole.position.equals(position) &&
      pole.quaternion.equals(quaternion) &&
      pole.scale.equals(scale),
  ),
  "转子专项分解归零后未精确恢复磁极",
);
check(
  !rotor.userData.localParts.some((part) => part.name.startsWith("mechanicalBrake_")) &&
    countParts("thrustBearingAssembly", "mechanicalBrake_") === D.mechanicalBrakes,
  "机械制动器层级错误",
);
check(
  countParts("statorActiveAssembly", "statorSlotGroup_") ===
    D.modeledStatorSlotGroups &&
    countParts("statorActiveAssembly", "topEndWindingGroup_") ===
      D.modeledEndWindingGroups &&
    countParts("statorActiveAssembly", "bottomEndWindingGroup_") ===
      D.modeledEndWindingGroups,
  "定子槽区或上下端部绕组数量错误",
);
check(
  countParts("thrustBearingAssembly", "thrustPad_") === D.thrustPads &&
    countParts("thrustBearingAssembly", "mechanicalBrake_") ===
      D.mechanicalBrakes &&
    countParts("thrustBearingAssembly", "brakePedestal_") ===
      D.mechanicalBrakes,
  "推力瓦、机械制动器或制动器支座数量错误",
);
check(
  countParts("coolingAssembly", "coolerBody_") === D.coolerCount &&
    countParts("coolingAssembly", "coolerHood_") === D.coolerCount &&
    countParts("coolingAssembly", "coolerLowerFlange_") === D.coolerCount &&
    countParts("coolingAssembly", "coolerUpperFlange_") === D.coolerCount &&
    countParts("coolingAssembly", "coolerDuct_") === D.coolerCount,
  "空冷器本体、风罩、法兰或风道数量错误",
);
check(
  byName.upperFrameAssembly.userData.localParts.filter(
    (part) => part.name === "oilTank",
  ).length === 1 &&
    countParts("upperFrameAssembly", "oilTankSupport_") === 2 &&
    countParts("upperFrameAssembly", "oilSupplyPipe") === 1 &&
    countParts("upperFrameAssembly", "oilReturnPipe") === 1 &&
    countParts("upperFrameAssembly", "oilPipeBracket_") === 2,
  "高位油箱、供回油管或管架数量错误",
);
check(
  close(
    authoringZRangeExact("upperFrameAssembly", "oilTank").min -
      authoringZRange("upperFrameAssembly", "oilTankSupport_").max,
    0,
  ),
  "高位油箱支撑未接触油箱底面",
);
check(
  close(
    authoringZRange("thrustBearingAssembly", "brakePedestal_").min -
      authoringZRange("lowerFrameAssembly", "radialArm_").max,
    0,
  ),
  "机械制动器支座未落在下机架支臂顶面",
);
check(
  D.rotorHubOuter < D.rotorSpiderInner &&
    D.rotorSpiderOuter < D.rotorRimInner &&
    D.rotorRimOuter < D.rotorMagnetInner,
  "转子载荷路径径向净空错误",
);

const modelBounds = new Box3().setFromObject(model);
const min = modelBounds.min.toArray();
const max = modelBounds.max.toArray();
for (let axis = 0; axis < 3; axis++) {
  check(min[axis] >= MODEL_BOUNDS.min[axis] - 1e-5, "模型越过声明下边界", { axis, min });
  check(max[axis] <= MODEL_BOUNDS.max[axis] + 1e-5, "模型越过声明上边界", { axis, max });
}

if (geometryReport.zfight.length) {
  warnings.push({
    kind: "coplanar",
    count: geometryReport.zfight.length,
    areaCm2: geometryReport.zfightTotalCm2,
    pairs: geometryReport.zfight,
  });
}
if (geometryReport.clash.length) {
  warnings.push({
    kind: "solid-clash",
    count: geometryReport.clash.length,
    pairs: geometryReport.clash,
  });
}

const report = {
  generatedAt: new Date().toISOString(),
  status: failures.length === 0 ? "pass" : "fail",
  coordinateSystem: {
    unit: "m",
    up: "+Y",
    origin: "基础底面中心",
    forward: "+Z",
  },
  declaredBounds: MODEL_BOUNDS,
  measuredBounds: { min, max },
  airGapM: gap,
  assemblies: ASSEMBLY_NAMES.map((name) => ({
    name,
    label: ASSEMBLY_LABELS[name],
    parts: byName[name].userData.localParts?.length ?? 0,
    counts: byName[name].userData.counts ?? {},
  })),
  semanticChecks: {
    supportGaps,
    rotorStructure: {
      support: rotorSupport.userData.localParts.length,
      yokeLayers: rotorYoke.userData.localParts.length,
      poles: poleGroups.length,
      partsPerPole: poleGroups.map((pole) => pole.children.length),
    },
  },
  topologyAudit: {
    parts: partAudit.length,
    failures: partAudit.filter((entry) => !entry.ok),
    emitted: emittedAudit,
  },
  geometryAudit: geometryReport,
  failures,
  warnings,
  limitations: [
    "非制造图尺寸，整体比例经过统一调整",
    "576 根定子线棒未逐根建模，以 28 组端部绕组示意",
    "轴承、空冷器和端子箱只保留可辨识轮廓与接口关系",
  ],
};

const docsDir = resolve(projectRoot, "docs");
await mkdir(docsDir, { recursive: true });
await writeFile(resolve(docsDir, "quality-report.json"), `${JSON.stringify(report, null, 2)}\n`);

console.log(
  `QUALITY ${report.status.toUpperCase()}  ${emittedAudit.meshes} meshes / ${emittedAudit.triangles} tris`,
);
console.log(
  `  topology ${partAudit.filter((entry) => entry.ok).length}/${partAudit.length}  ` +
    `zfight ${geometryReport.zfight.length} (${geometryReport.zfightTotalCm2} cm2)  ` +
    `clash ${geometryReport.clash.length}  defects ${geometryReport.defects.length}`,
);
console.log(
  `  bounds [${min.map((v) => v.toFixed(3)).join(", ")}] -> ` +
    `[${max.map((v) => v.toFixed(3)).join(", ")}]  air gap ${gap.toFixed(3)} m`,
);
if (failures.length) {
  console.error("FAILURES");
  for (const failure of failures) console.error(`- ${failure}`);
}
if (geometryReport.zfight.length) {
  console.log("COPLANAR");
  console.table(geometryReport.zfight);
}
if (geometryReport.clash.length) {
  console.log("SOLID CLASH");
  console.table(geometryReport.clash);
}

if (failures.length) process.exitCode = 1;
