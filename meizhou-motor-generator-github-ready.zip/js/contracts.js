export const D = Object.freeze({
  foundationRadius: 6.15,
  foundationHeight: 0.42,
  anchorSeatTop: 0.72,

  lowerFrameOuter: 4.02,
  lowerFrameInner: 3.08,
  lowerFrameZ0: 1.02,
  lowerFrameZ1: 1.42,

  statorHousingOuter: 4.055,
  statorHousingInner: 3.68,
  statorHousingZ0: 1.88,
  statorHousingZ1: 5.95,

  statorCoreOuter: 3.625,
  statorCoreInner: 3.0,
  statorCoreZ0: 2.38,
  statorCoreZ1: 5.02,
  statorCoreStackSegments: 75,
  statorVentDuctLayers: 74,
  statorThroughBolts: 144,
  statorPositioningRibs: 72,

  rotorMagnetInner: 2.748,
  rotorMagnetOuter: 2.954,
  rotorMagnetZ0: 2.44,
  rotorMagnetZ1: 4.96,
  rotorHubOuter: 1.035,
  rotorSpiderInner: 1.04,
  rotorSpiderOuter: 2.335,
  rotorRimInner: 2.34,
  rotorRimOuter: 2.743,

  shaftRadius: 0.5,
  shaftZ0: 0.86,
  shaftZ1: 7.78,

  upperFrameOuter: 5.355,
  upperFrameInner: 3.05,
  upperFrameZ0: 5.95,
  upperFrameZ1: 7.01,

  coolerCenterRadius: 4.65,
  coolerRadius: 0.37,
  coolerZ0: 2.28,
  coolerZ1: 5.32,

  poleCount: 16,
  polePairs: 8,
  statorSlotReferenceCount: 576,
  modeledStatorSlotGroups: 36,
  modeledEndWindingGroups: 28,
  rotorSpiderArms: 7,
  rotorRimSegments: 9,
  lowerFrameArms: 10,
  upperFrameArms: 8,
  thrustPads: 10,
  mechanicalBrakes: 10,
  inspectionWindows: 8,
  coolerCount: 8,
  airGapM: 0.046,
  poleMassKg: 8629,
  lowerFrameMassT: 43,
  upperFrameMaxArmHeight: 1.06,
  excitationBrushes: 2,
  oilMistExtractors: 3,
});

export const ASSEMBLY_NAMES = Object.freeze([
  "foundationAssembly",
  "lowerFrameAssembly",
  "thrustBearingAssembly",
  "statorHousingAssembly",
  "statorActiveAssembly",
  "rotorAssembly",
  "upperFrameAssembly",
  "coolingAssembly",
  "excitationAndLeads",
]);

export const ASSEMBLY_LABELS = Object.freeze({
  foundationAssembly: ["基础与锚固座", "混凝土基础、10 个找平/锚固座"],
  lowerFrameAssembly: ["下机架 / 下导轴承", "10 条支臂；下导与推力轴承位于下部轴承区"],
  thrustBearingAssembly: ["推力轴承与制动", "镜板、10 块推力瓦和 10 个机械制动器示意"],
  statorHousingAssembly: ["定子机座", "8 个真实贯通检修窗"],
  statorActiveAssembly: ["定子铁芯 / 绕组", "完整铁芯、36 个可见槽区和 28 组端部绕组"],
  rotorAssembly: ["转子与主轴", "16 个凸极（8 对），每极含极身、极靴和绕组"],
  upperFrameAssembly: ["上机架 / 上导轴承", "8 条支臂、上导轴承和高位油箱"],
  coolingAssembly: ["立式空冷器", "8 台空冷器、风罩、法兰和连接风道"],
  excitationAndLeads: ["端子箱 / 引出线", "三相母线与中性点示意"],
});

export const MODEL_BOUNDS = Object.freeze({
  min: Object.freeze([-6.15, 0, -6.15]),
  max: Object.freeze([6.15, 7.78, 6.15]),
});

export function airGapMeasurement() {
  return D.statorCoreInner - D.rotorMagnetOuter;
}

export const TEACHING_DATA = Object.freeze({
  baseline: "梅蓄单厂教学口径",
  sourceNote:
    "【课件原文】单厂教学定值。现场以现行运行规程、保护定值单和批准图纸为准。",
  safety:
    "本模型用于结构和原理教学，不能替代厂家图纸、现场运行规程、检修工艺卡和操作票。页面中的间隙值、温度定值、动画方向和操作顺序均为教学示意；真实机组执行前必须与当前有效版本核对，并经现场批准人员确认。",
  temperatureLimits: Object.freeze([
    ["定子绕组", 105, 115],
    ["定子铁芯", 100, 110],
    ["定子压指", 100, 110],
    ["上导瓦", 65, 75],
    ["下导瓦", 65, 75],
    ["推力瓦", 75, 85],
    ["冷风", 45, null],
    ["热风", 70, null],
    ["油盆", 55, null],
    ["冷却水进口", 32, null],
    ["冷却水出口", 45, null],
  ]),
  voltage: Object.freeze({ minKv: 17.1, maxKv: 18.9 }),
  energy: Object.freeze({
    generation: [
      "水体势能",
      "压力能 / 动能",
      "水泵水轮机转轮机械能",
      "主轴扭矩",
      "转子直流励磁形成磁场",
      "定子线棒感应三相交流电动势",
      "发电机出口开关 GCB",
      "主变",
      "电网",
    ],
    pumping: [
      "电网",
      "主变",
      "GCB",
      "定子通入三相电流产生旋转磁场",
      "转子在励磁下同步跟随",
      "主轴机械能",
      "水泵水轮机",
      "抽水",
    ],
    excitation: [
      "定子端电压",
      "励磁变",
      "可控硅整流",
      "滑环 / 碳刷",
      "转子励磁绕组",
    ],
  }),
  waterGuide: Object.freeze({
    title: "水导轴承（水泵水轮机侧）",
    padCount: 10,
    indexStepDeg: 36,
    padRadiusMm: 736,
    nominalDiameterMm: 1466,
    shaftCollarDiameterMm: 1460,
    shaftNominalSurfaceRadiusM: 0.73572,
    padHeightMm: 400,
    gapRangeMm: Object.freeze([0.25, 0.3]),
    coldGapMm: 0.3,
    hotGapMm: 0.25,
    customRangeMm: Object.freeze([0, 1]),
    visualScale: 100,
    defaultTargetMm: 0.3,
    defaultMeasuredMm: 0.3,
    nearTargetMm: 0.005,
    material: "锻钢瓦背 + 巴氏合金瓦面",
    supportChain: Object.freeze([
      "顶瓦垫块",
      "半 V 形楔子块",
      "调整块",
      "调整件",
      "球面接触",
      "楔子板挡块",
      "抗重块",
      "推力支撑",
    ]),
    unverified:
      "当前未核实项：真实机组当前水导间隙、现场允许目标与偏差、有效紧固力矩、真实调整/紧固/复装顺序、当前设备版本适用性。",
  }),
});

export function assumptionSummary() {
  return {
    coordinateSystem: "渲染坐标 Y 向上，单位米；坐标原点位于基础底面中心",
    envelope: "约 12.3 × 7.78 × 12.3 m（含冷却器与引出箱的近似总边界）",
    scaleBasis:
      "结构参考同等级 300 MW 立轴发电电动机；整体尺寸经过统一尺度调整，不是梅蓄制造图尺寸",
    simplified: [
      "576 根定子线棒不逐根建模，以 36 个可见槽区和 28 组端部绕组示意",
      "16 个磁极（8 对）保留极身、极靴和绕组层级，不复制每张磁极片",
      "轴承、空冷器、制动器和端子箱只保留可辨识轮廓与接口关系",
      "水导轴承间隙动画固定放大 100×；读数始终为真实毫米值",
    ],
  };
}
