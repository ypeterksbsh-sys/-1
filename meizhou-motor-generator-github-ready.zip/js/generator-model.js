import { Color, Group, MeshStandardMaterial } from "three";
import {
  annularPrism,
  box,
  ccw,
  circle,
  cleanMesh,
  prism,
  rotateZ,
  tubeAlong,
} from "../vendor/geometry-quality-kit/procedural-mesh.js";
import { buildNamedAuditGroup } from "../vendor/geometry-quality-kit/assembly.js";
import {
  ASSEMBLY_LABELS,
  ASSEMBLY_NAMES,
  D,
} from "./contracts.js";

const TAU = Math.PI * 2;
const MATERIAL_SLOTS = [
  "concrete",
  "steel",
  "darkSteel",
  "rotor",
  "core",
  "copper",
  "shell",
  "duct",
  "terminal",
  "safety",
];

function grayMaterial(name, color, roughness, metalness = 0.2) {
  return new MeshStandardMaterial({
    name,
    color: new Color(color),
    roughness,
    metalness,
    flatShading: false,
  });
}

export function createBaseGrayMaterials() {
  return {
    concrete: grayMaterial("warm-gray concrete", 0xb9b7b1, 0.94, 0.02),
    steel: grayMaterial("structural steel", 0x8f9598, 0.58, 0.3),
    darkSteel: grayMaterial("dark steel", 0x5f676b, 0.5, 0.38),
    rotor: grayMaterial("rotor steel", 0x7d8589, 0.5, 0.36),
    core: grayMaterial("laminated core", 0x676e72, 0.68, 0.24),
    copper: grayMaterial("desaturated copper", 0x9c9892, 0.5, 0.42),
    shell: grayMaterial("painted housing", 0xa9adae, 0.7, 0.18),
    duct: grayMaterial("air duct", 0x858b8e, 0.72, 0.16),
    terminal: grayMaterial("terminal enclosure", 0x969b9d, 0.64, 0.2),
    safety: grayMaterial("lighter handling steel", 0xc2c3bf, 0.55, 0.24),
  };
}

function cloneMaterialSet(base) {
  return Object.fromEntries(
    MATERIAL_SLOTS.map((slot) => [slot, base[slot].clone()]),
  );
}

export function createAssemblyMaterials(base = createBaseGrayMaterials()) {
  return Object.fromEntries(
    ASSEMBLY_NAMES.map((assembly) => [assembly, cloneMaterialSet(base)]),
  );
}

function ring(innerRadius, outerRadius, z0, z1, segments = 64, x = 0, y = 0) {
  const mesh = annularPrism(
    circle(outerRadius, segments),
    circle(innerRadius, segments),
    z0,
    z1,
  );
  if (x || y) {
    for (const vertex of mesh.verts) {
      vertex[0] += x;
      vertex[1] += y;
    }
  }
  return mesh;
}

function cylinder(radius, z0, z1, segments = 48, x = 0, y = 0) {
  const mesh = prism(circle(radius, segments), z0, z1);
  if (x || y) {
    for (const vertex of mesh.verts) {
      vertex[0] += x;
      vertex[1] += y;
    }
  }
  return mesh;
}

function arcSector(innerRadius, outerRadius, centerAngle, sweep, z0, z1, segments = 6) {
  const a0 = centerAngle - sweep * 0.5;
  const a1 = centerAngle + sweep * 0.5;
  const outer = [];
  const inner = [];
  for (let i = 0; i <= segments; i++) {
    const angle = a0 + (a1 - a0) * (i / segments);
    outer.push([Math.cos(angle) * outerRadius, Math.sin(angle) * outerRadius]);
  }
  for (let i = segments; i >= 0; i--) {
    const angle = a0 + (a1 - a0) * (i / segments);
    inner.push([Math.cos(angle) * innerRadius, Math.sin(angle) * innerRadius]);
  }
  return prism(ccw([...outer, ...inner]), z0, z1);
}

function radialBox(innerRadius, outerRadius, width, z0, z1, angle) {
  const mesh = box(
    -width * 0.5,
    innerRadius,
    z0,
    width * 0.5,
    outerRadius,
    z1,
  );
  rotateZ(mesh, angle);
  return mesh;
}

function radialAnnularArm(innerRadius, outerRadius, width, z0, z1, angle) {
  const halfWidth = width * 0.5;
  const endClearance = 0.008;
  const armInnerRadius = innerRadius + endClearance;
  const armOuterRadius = outerRadius - endClearance;
  const profile = [];
  const samples = 6;
  for (let i = 0; i <= samples; i++) {
    const y = -halfWidth + width * i / samples;
    profile.push([Math.sqrt(armInnerRadius * armInnerRadius - y * y), y]);
  }
  for (let i = samples; i >= 0; i--) {
    const y = -halfWidth + width * i / samples;
    profile.push([Math.sqrt(armOuterRadius * armOuterRadius - y * y), y]);
  }
  const mesh = prism(ccw(profile), z0, z1);
  rotateZ(mesh, angle);
  return mesh;
}

function radialCoolerDuct(
  innerRadius,
  bodyCenterRadius,
  bodyRadius,
  width,
  z0,
  z1,
  angle,
) {
  const halfWidth = width * 0.5;
  const endClearance = 0.008;
  const ductInnerRadius = innerRadius + endClearance;
  const profile = [];
  const samples = 6;
  for (let i = 0; i <= samples; i++) {
    const y = -halfWidth + width * i / samples;
    profile.push([Math.sqrt(ductInnerRadius * ductInnerRadius - y * y), y]);
  }
  for (let i = samples; i >= 0; i--) {
    const y = -halfWidth + width * i / samples;
    profile.push([
      bodyCenterRadius - Math.sqrt(bodyRadius * bodyRadius - y * y) - endClearance,
      y,
    ]);
  }
  const mesh = prism(ccw(profile), z0, z1);
  rotateZ(mesh, angle);
  return mesh;
}

function boxAt(x, y, z0, widthX, widthY, z1) {
  return box(
    x - widthX * 0.5,
    y - widthY * 0.5,
    z0,
    x + widthX * 0.5,
    y + widthY * 0.5,
    z1,
  );
}

function circularProfile(radius, segments = 8) {
  return circle(radius, segments);
}

function rectangularProfile(width, height) {
  return [
    [-width * 0.5, -height * 0.5],
    [width * 0.5, -height * 0.5],
    [width * 0.5, height * 0.5],
    [-width * 0.5, height * 0.5],
  ];
}

function endWindingPath(index, top) {
  const count = D.modeledEndWindingGroups;
  const a0 = TAU * index / count;
  const a1 = a0 + 0.055;
  const a2 = a0 + 0.1;
  const zCore = top ? D.statorCoreZ1 + 0.02 : D.statorCoreZ0 - 0.02;
  const zBend = top ? zCore + 0.24 : zCore - 0.24;
  const zCrown = top ? zBend + 0.1 : zBend - 0.1;
  const zEnd = top ? zBend - 0.08 : zBend + 0.08;
  const radiusA = 3.04;
  const radiusB = 3.13;
  const radiusC = 3.3;
  return [
    [radiusA * Math.cos(a0), radiusA * Math.sin(a0), zCore],
    [radiusB * Math.cos(a0), radiusB * Math.sin(a0), zBend],
    [(radiusC - 0.02) * Math.cos((a0 + a1) * 0.5), (radiusC - 0.02) * Math.sin((a0 + a1) * 0.5), zCrown],
    [radiusC * Math.cos(a1), radiusC * Math.sin(a1), zEnd],
    [radiusC * Math.cos(a2), radiusC * Math.sin(a2), zBend - (top ? 0.15 : -0.15)],
  ];
}

function factoryFor(root, assemblyName) {
  return function part(localName, slot, meshData, contract = null) {
    return {
      name: `${root}.${assemblyName}.${localName}`,
      slot,
      meshData,
      contract,
    };
  };
}

function makeAssembly(root, assemblyName, parts, materials, userData) {
  for (const part of parts) cleanMesh(part.meshData);
  const group = buildNamedAuditGroup(parts, materials, {
    name: `${root}.${assemblyName}`,
    clean: false,
    castShadow: assemblyName !== "statorActiveAssembly",
    receiveShadow: true,
  });
  group.name = assemblyName;
  group.userData = {
    ...userData,
    auditParts: parts.map(({ name, meshData, contract }) => ({
      name,
      meshData,
      contract,
    })),
    localParts: parts.map(({ name, slot, contract }) => ({
      name: name.slice(`${root}.${assemblyName}.`.length),
      globalName: name,
      slot,
      contract,
    })),
  };
  const shellNames = new Set(
    parts.filter((part) => part.slot === "shell").map((part) => part.name),
  );
  group.traverse((object) => {
    if (object.isMesh && shellNames.has(object.name)) {
      object.userData.shell = true;
    }
  });
  return group;
}

function makeRotorSubassembly(name, materials, userData) {
  const group = new Group();
  group.name = name;
  group.userData = {
    ...userData,
    sectionShell: true,
  };
  group.userData.localParts = (userData.localParts ?? []).map((mesh) => ({
    name: mesh.name.slice(mesh.name.lastIndexOf(".") + 1),
    globalName: mesh.name,
    slot: mesh.userData.geometryPart?.slot,
    contract: mesh.userData.geometryPart?.contract ?? null,
  }));
  for (const mesh of group.userData.localParts) {
    const target = userData.localParts.find((entry) => entry.name.endsWith(`.${mesh.name}`));
    if (!target) continue;
    const slot = target.userData.geometryPart?.slot;
    target.material = materials[slot];
  }
  return group;
}

function buildFoundation(root, materials) {
  const assembly = "foundationAssembly";
  const part = factoryFor(root, assembly);
  const parts = [
    part("baseSlab", "concrete", cylinder(D.foundationRadius, 0, D.foundationHeight, 96)),
    part(
      "centerPlinth",
      "concrete",
      cylinder(1.32, D.foundationHeight + 0.09, D.anchorSeatTop, 48),
    ),
    part(
      "lowerPlinth",
      "concrete",
      cylinder(5.75, D.foundationHeight, D.foundationHeight + 0.1, 72),
    ),
  ];

  for (let i = 0; i < D.lowerFrameArms; i++) {
    const angle = TAU * i / D.lowerFrameArms;
    parts.push(
      part(
        `anchorSeat_${i + 1}`,
        "steel",
        radialBox(
          3.6,
          4.34,
          0.56,
          D.foundationHeight + 0.1,
          D.anchorSeatTop,
          angle,
        ),
      ),
    );
  }

  return makeAssembly(root, assembly, parts, materials, {
    explode: [0, 0, 0],
    stage: 0,
    labelAnchor: [0, 0.3, 5.7],
    description: ASSEMBLY_LABELS[assembly][1],
    counts: { anchorSeats: D.lowerFrameArms },
  });
}

function buildLowerFrame(root, materials) {
  const assembly = "lowerFrameAssembly";
  const part = factoryFor(root, assembly);
  const parts = [
    part(
      "bearingRing",
      "steel",
      ring(D.lowerFrameInner, D.lowerFrameOuter, D.lowerFrameZ0, D.lowerFrameZ1, 72),
    ),
    part("centerHub", "darkSteel", ring(0.835, 1.22, D.anchorSeatTop, D.lowerFrameZ1, 48)),
  ];

  for (let i = 0; i < D.lowerFrameArms; i++) {
    const angle = TAU * i / D.lowerFrameArms;
    parts.push(
      part(
        `supportFoot_${i + 1}`,
        "darkSteel",
        radialBox(3.64, 4.24, 0.48, D.anchorSeatTop, D.lowerFrameZ0, angle),
      ),
      part(
        `radialArm_${i + 1}`,
        "steel",
        radialAnnularArm(
          1.22,
          D.lowerFrameInner,
          0.38,
          D.lowerFrameZ0 + 0.015,
          D.lowerFrameZ1,
          angle,
        ),
      ),
    );
  }

  return makeAssembly(root, assembly, parts, materials, {
    explode: [0, 0, 0],
    stage: 0,
    sectionShell: true,
    labelAnchor: [0, 1.22, -3.55],
    description: ASSEMBLY_LABELS[assembly][1],
    counts: {
      radialArms: D.lowerFrameArms,
      supportFeet: D.lowerFrameArms,
    },
  });
}

function buildThrustBearing(root, materials) {
  const assembly = "thrustBearingAssembly";
  const part = factoryFor(root, assembly);
  const parts = [
    part("shaftSleeve", "darkSteel", ring(0.52, 0.83, D.anchorSeatTop, 1.42, 40)),
    part("thrustCollar", "steel", ring(0.835, 2.02, D.lowerFrameZ1, 1.5, 64)),
    part("mirrorPlate", "safety", ring(0.96, 1.96, 1.5, 1.54, 64)),
  ];

  for (let i = 0; i < D.thrustPads; i++) {
    const angle = TAU * i / D.thrustPads;
    parts.push(
      part(
        `thrustPad_${i + 1}`,
        "steel",
        radialBox(1.18, 1.84, 0.36, 1.54, 1.62, angle),
      ),
      part(
        `brakePedestal_${i + 1}`,
        "steel",
        radialBox(2.06, 2.3, 0.22, D.lowerFrameZ1, 1.5, angle),
      ),
      part(
        `mechanicalBrake_${i + 1}`,
        "darkSteel",
        radialBox(2.06, 2.26, 0.2, 1.5, 1.63, angle),
      ),
    );
  }

  return makeAssembly(root, assembly, parts, materials, {
    explode: [0, 0, 0],
    stage: 0,
    labelAnchor: [0, 1.05, 1.75],
    description: ASSEMBLY_LABELS[assembly][1],
    counts: {
      thrustPads: D.thrustPads,
      mechanicalBrakes: D.mechanicalBrakes,
    },
  });
}

function buildStatorHousing(root, materials) {
  const assembly = "statorHousingAssembly";
  const part = factoryFor(root, assembly);
  const pillarSweep = TAU / D.inspectionWindows * 0.28;
  const parts = [
    part(
      "lowerBand",
      "shell",
      ring(
        D.statorHousingInner,
        D.statorHousingOuter,
        D.statorHousingZ0,
        D.statorHousingZ0 + 0.3,
        72,
      ),
    ),
    part(
      "upperBand",
      "shell",
      ring(
        D.statorHousingInner,
        D.statorHousingOuter,
        D.statorHousingZ1 - 0.3,
        D.statorHousingZ1,
        72,
      ),
    ),
  ];

  for (let i = 0; i < D.inspectionWindows; i++) {
    const angle = TAU * i / D.inspectionWindows;
    parts.push(
      part(
        `windowPillar_${i + 1}`,
        "shell",
        arcSector(
          D.statorHousingInner,
          D.statorHousingOuter,
          angle,
          pillarSweep,
          D.statorHousingZ0 + 0.3,
          D.statorHousingZ1 - 0.3,
          5,
        ),
      ),
      part(
        `baseBracket_${i + 1}`,
        "steel",
        radialBox(3.58, 4.2, 0.5, D.lowerFrameZ1, D.statorHousingZ0, angle + pillarSweep * 0.5),
      ),
    );
  }

  return makeAssembly(root, assembly, parts, materials, {
    explode: [0, 2.6, 0],
    stage: 0,
    labelAnchor: [0, 4.05, 3.95],
    description: ASSEMBLY_LABELS[assembly][1],
    counts: {
      inspectionWindows: D.inspectionWindows,
      windowOpeningsThroughWall: true,
    },
  });
}

function buildStatorActive(root, materials) {
  const assembly = "statorActiveAssembly";
  const part = factoryFor(root, assembly);
  const parts = [
    part(
      "coreOuterYoke",
      "core",
      ring(3.168, D.statorCoreOuter, D.statorCoreZ0, D.statorCoreZ1, 96),
    ),
    part(
      "bottomClampRing",
      "steel",
      ring(3.44, D.statorCoreOuter, D.statorCoreZ0 - 0.11, D.statorCoreZ0, 72),
    ),
    part(
      "topClampRing",
      "steel",
      ring(3.44, D.statorCoreOuter, D.statorCoreZ1, D.statorCoreZ1 + 0.11, 72),
    ),
  ];

  for (let i = 0; i < D.modeledStatorSlotGroups; i++) {
    const angle = TAU * i / D.modeledStatorSlotGroups;
    parts.push(
      part(
        `statorSlotGroup_${i + 1}`,
        "darkSteel",
        arcSector(
          D.statorCoreInner,
          3.16,
          angle,
          TAU / D.modeledStatorSlotGroups * 0.84,
          D.statorCoreZ0,
          D.statorCoreZ1,
          4,
        ),
      ),
    );
  }

  for (let i = 0; i < D.modeledEndWindingGroups; i++) {
    for (const top of [false, true]) {
      const label = top ? "top" : "bottom";
      parts.push(
        part(
          `${label}EndWindingGroup_${i + 1}`,
          "copper",
          tubeAlong(
            endWindingPath(i, top),
            rectangularProfile(0.075, 0.15),
            { up: [0, 0, 1], cap: true },
          ),
        ),
      );
    }
  }

  return makeAssembly(root, assembly, parts, materials, {
    explode: [0, 0, 0],
    stage: 0,
    labelAnchor: [0, 5.35, -2.75],
    description: ASSEMBLY_LABELS[assembly][1],
    sectionShell: true,
    counts: {
      statorSlotGroups: D.modeledStatorSlotGroups,
      statorSlotReferenceCount: D.statorSlotReferenceCount,
      endWindingGroups: D.modeledEndWindingGroups,
    },
  });
}

function buildRotor(root, materials) {
  const assembly = "rotorAssembly";
  const part = factoryFor(root, assembly);
  const parts = [
    part("mainShaft", "darkSteel", cylinder(D.shaftRadius, D.shaftZ0, D.shaftZ1, 40)),
    part("lowerCouplingFlange", "darkSteel", ring(0.502, 0.78, 1.42, 1.66, 40)),
    part("topCouplingFlange", "safety", ring(0.502, 0.9, 7.56, D.shaftZ1, 40)),
    part("rotorHub", "rotor", ring(0.52, D.rotorHubOuter, 1.66, 6.0, 56)),
    part(
      "lowerSpiderPlate",
      "rotor",
      ring(D.rotorSpiderInner, D.rotorSpiderOuter, 1.64, 1.86, 64),
    ),
    part(
      "upperSpiderPlate",
      "rotor",
      ring(D.rotorSpiderInner, D.rotorSpiderOuter, 5.8, 6.02, 64),
    ),
  ];

  for (let i = 0; i < D.rotorSpiderArms; i++) {
    const angle = TAU * i / D.rotorSpiderArms;
    parts.push(
      part(
        `spiderArm_${i + 1}`,
        "darkSteel",
        radialAnnularArm(
          D.rotorSpiderInner,
          D.rotorRimInner,
          0.56,
          3.2,
          3.62,
          angle,
        ),
      ),
    );
  }

  const rimZ0 = 1.5;
  const rimZ1 = 5.98;
  const segmentHeight = (rimZ1 - rimZ0) / D.rotorRimSegments;
  for (let i = 0; i < D.rotorRimSegments; i++) {
    parts.push(
      part(
        `yokeLayer_${String(i + 1).padStart(2, "0")}`,
        "rotor",
        ring(
          D.rotorRimInner,
          D.rotorRimOuter,
          rimZ0 + i * segmentHeight + 0.018,
          rimZ0 + (i + 1) * segmentHeight - 0.018,
          72,
        ),
      ),
    );
  }

  const polePitch = TAU / D.poleCount;
  for (let i = 0; i < D.poleCount; i++) {
    const angle = TAU * i / D.poleCount;
    const poleNumber = String(i + 1).padStart(2, "0");
    parts.push(
      part(
        `poleBody_${poleNumber}`,
        "core",
        arcSector(
          D.rotorMagnetInner,
          2.844,
          angle,
          polePitch * 0.72,
          2.56,
          4.84,
          6,
        ),
      ),
      part(
        `poleShoe_${poleNumber}`,
        "steel",
        arcSector(
          2.910,
          D.rotorMagnetOuter,
          angle,
          polePitch * 0.9,
          2.46,
          4.94,
          6,
        ),
      ),
      part(
        `poleWindingLower_${poleNumber}`,
        "copper",
        arcSector(
          2.852,
          2.902,
          angle,
          polePitch * 0.84,
          2.58,
          3.38,
          6,
        ),
      ),
      part(
        `poleWindingUpper_${poleNumber}`,
        "copper",
        arcSector(
          2.852,
          2.902,
          angle,
          polePitch * 0.84,
          3.46,
          4.82,
          6,
        ),
      ),
    );
  }

  const rotor = makeAssembly(root, assembly, parts, materials, {
    explode: [0, 4.8, 0],
    stage: 1,
    labelAnchor: [0, 7.9, 0.5],
    description: ASSEMBLY_LABELS[assembly][1],
    sectionShell: true,
    connections: ["主轴", "转子支架", "转子磁轭", "16 个转子磁极"],
    counts: {
      poles: D.poleCount,
      poleShoes: D.poleCount,
      poleWindings: D.poleCount * 2,
      spiderArms: D.rotorSpiderArms,
      rimSegments: D.rotorRimSegments,
    },
  });

  const supportMaterials = cloneMaterialSet(materials);
  supportMaterials.rotor.color.offsetHSL(0, -0.02, -0.035);
  supportMaterials.darkSteel.color.offsetHSL(0, -0.02, -0.035);
  const yokeMaterials = cloneMaterialSet(materials);
  yokeMaterials.rotor.color.offsetHSL(0, -0.01, 0.045);
  yokeMaterials.core.color.offsetHSL(0, -0.01, 0.025);
  const poleMaterials = cloneMaterialSet(materials);
  poleMaterials.copper.color.setHex(0x8f7f70);

  const rotorSupportAssembly = new Group();
  rotorSupportAssembly.name = "rotorSupportAssembly";
  const rotorYokeAssembly = new Group();
  rotorYokeAssembly.name = "rotorYokeAssembly";
  const rotorPoleAssembly = new Group();
  rotorPoleAssembly.name = "rotorPoleAssembly";

  const supportMeshes = [];
  const yokeMeshes = [];
  const poleMeshes = new Map();
  const supportNames = new Set([
    "rotorHub",
    "upperSpiderPlate",
    "lowerSpiderPlate",
  ]);

  for (const mesh of [...rotor.children]) {
    const localName = mesh.name.slice(mesh.name.lastIndexOf(".") + 1);
    if (supportNames.has(localName) || localName.startsWith("spiderArm_")) {
      mesh.material = supportMaterials[mesh.userData.geometryPart.slot];
      mesh.userData.pickRoot = rotorSupportAssembly;
      mesh.userData.highlightRoot = rotorSupportAssembly;
      supportMeshes.push(mesh);
      rotorSupportAssembly.attach(mesh);
      continue;
    }
    if (localName.startsWith("yokeLayer_")) {
      mesh.material = yokeMaterials[mesh.userData.geometryPart.slot];
      mesh.userData.pickRoot = rotorYokeAssembly;
      mesh.userData.highlightRoot = rotorYokeAssembly;
      yokeMeshes.push(mesh);
      rotorYokeAssembly.attach(mesh);
      continue;
    }
    const poleMatch = localName.match(
      /^(poleBody|poleShoe|poleWindingLower|poleWindingUpper)_(\d{2})$/,
    );
    if (!poleMatch) continue;
    const [, , poleNumber] = poleMatch;
    mesh.material = poleMaterials[mesh.userData.geometryPart.slot];
    if (!poleMeshes.has(poleNumber)) poleMeshes.set(poleNumber, []);
    poleMeshes.get(poleNumber).push(mesh);
  }

  rotor.add(rotorSupportAssembly, rotorYokeAssembly, rotorPoleAssembly);
  rotorSupportAssembly.userData = {
    title: "转子支架",
    description:
      "连接主轴并传递转子载荷，把磁轭和磁极支撑成整体。",
    teachingNote: "教学示意；支架与主轴、磁轭的连接轮廓不代表现场拆装顺序。",
    connections: ["主轴", "转子磁轭"],
    sectionShell: true,
    localParts: supportMeshes.map((mesh) => ({
      name: mesh.name.slice(mesh.name.lastIndexOf(".") + 1),
      globalName: mesh.name,
      slot: mesh.userData.geometryPart.slot,
      contract: mesh.userData.geometryPart.contract,
    })),
    counts: { spiderArms: D.rotorSpiderArms },
  };
  rotorYokeAssembly.userData = {
    title: "转子磁轭",
    description:
      "固定在支架外侧，用于安装磁极、完善磁路并承受旋转时的离心力。",
    teachingNote: "按原有轴向分段保留层间接缝；模型不补造叠片数量。",
    connections: ["转子支架", "16 个转子磁极"],
    sectionShell: true,
    localParts: yokeMeshes.map((mesh) => ({
      name: mesh.name.slice(mesh.name.lastIndexOf(".") + 1),
      globalName: mesh.name,
      slot: mesh.userData.geometryPart.slot,
      contract: mesh.userData.geometryPart.contract,
    })),
    counts: { layers: D.rotorRimSegments },
  };
  rotorPoleAssembly.userData = {
    title: "转子磁极（16 极）",
    description:
      "16 个磁极挂装在磁轭外圆周；励磁绕组建立主磁场，与定子形成机电能量转换所需的耦合磁场。",
    teachingNote:
      "直流励磁后形成交替磁极；模型不标定精确 N/S 极性或线圈电流方向。",
    connections: ["转子磁轭", "定子铁芯（隔气隙）"],
    sectionShell: true,
    localParts: [],
    counts: { poles: D.poleCount, windings: D.poleCount * 2 },
  };

  for (const [poleNumber, meshes] of poleMeshes) {
    const pole = new Group();
    pole.name = `pole_${poleNumber}`;
    pole.userData = {
      title: `转子磁极 ${poleNumber}/16`,
      description:
        "极身、极靴和上下励磁绕组组成单个凸极；整个磁极组在点击时共同高亮。",
      teachingNote:
        "所属转子磁极组。模型不标定精确 N/S 极性或线圈电流方向。",
      connections: ["转子磁轭", "转子磁极组"],
      sectionShell: true,
      localParts: [],
      counts: { poleBodies: 1, poleShoes: 1, poleWindings: 2 },
    };
    for (const mesh of meshes) {
      mesh.userData.pickRoot = pole;
      mesh.userData.highlightRoot = rotorPoleAssembly;
      pole.attach(mesh);
    }
    pole.userData.localParts = meshes.map((mesh) => ({
      name: mesh.name.slice(mesh.name.lastIndexOf(".") + 1),
      globalName: mesh.name,
      slot: mesh.userData.geometryPart.slot,
      contract: mesh.userData.geometryPart.contract,
    }));
    rotorPoleAssembly.userData.localParts.push(...pole.userData.localParts);
    rotorPoleAssembly.add(pole);
  }

  rotor.userData.subassemblies = [
    "rotorSupportAssembly",
    "rotorYokeAssembly",
    "rotorPoleAssembly",
  ];
  rotor.userData.connections = [
    "主轴 -> 转子支架 -> 转子磁轭 -> 16 个转子磁极",
  ];
  return rotor;
}

function buildUpperFrame(root, materials) {
  const assembly = "upperFrameAssembly";
  const part = factoryFor(root, assembly);
  const parts = [
    part(
      "upperRing",
      "steel",
      ring(D.upperFrameInner, D.upperFrameOuter, D.upperFrameZ0, D.upperFrameZ1, 72),
    ),
    part("guideBearingHousing", "darkSteel", ring(0.53, 1.08, 6.0, 6.72, 48)),
    part("upperGuideCollar", "safety", ring(1.09, 1.34, 6.5, 6.68, 48)),
    part(
      "oilTank",
      "terminal",
      boxAt(3.75, 0, 7.12, 1.0, 0.72, 7.55),
    ),
    part("oilTankSupport_1", "steel", cylinder(0.05, 7.01, 7.12, 12, 3.42, 0)),
    part("oilTankSupport_2", "steel", cylinder(0.05, 7.01, 7.12, 12, 4.08, 0)),
    part(
      "oilSupplyPipe",
      "copper",
      tubeAlong(
        [
          [3.38, -0.15, 7.075],
          [3.3, -0.15, 7.075],
          [2.45, -0.15, 7.075],
          [1.58, -0.12, 7.025],
          [1.08, -0.08, 6.74],
        ],
        circularProfile(0.045, 10),
        { up: [0, 0, 1], cap: true },
      ),
    ),
    part(
      "oilReturnPipe",
      "copper",
      tubeAlong(
        [
          [1.08, 0.08, 6.74],
          [1.55, 0.1, 7.025],
          [2.55, 0.12, 7.065],
          [3.62, 0.18, 7.065],
          [3.98, 0.2, 7.075],
        ],
        circularProfile(0.045, 10),
        { up: [0, 0, 1], cap: true },
      ),
    ),
    part(
      "oilPipeBracket_1",
      "steel",
      boxAt(3.3, -0.15, 7.01, 0.08, 0.08, 7.03),
    ),
    part(
      "oilPipeBracket_2",
      "steel",
      boxAt(3.62, 0.18, 7.01, 0.08, 0.08, 7.02),
    ),
  ];

  for (let i = 0; i < D.upperFrameArms; i++) {
    const angle = TAU * i / D.upperFrameArms + Math.PI / 8;
    parts.push(
      part(
        `upperArm_${i + 1}`,
        "steel",
        radialAnnularArm(1.08, D.upperFrameInner, 0.42, 6.06, 6.26, angle),
      ),
      part(
        `liftingLug_${i + 1}`,
        "safety",
        boxAt(
          Math.cos(angle) * 3.58,
          Math.sin(angle) * 3.58,
          6.35,
          0.24,
          0.24,
          6.74,
        ),
      ),
    );
  }

  return makeAssembly(root, assembly, parts, materials, {
    explode: [0, 7.8, 0],
    stage: 2,
    sectionShell: true,
    labelAnchor: [0, 6.55, -3.1],
    description: ASSEMBLY_LABELS[assembly][1],
    counts: {
      upperArms: D.upperFrameArms,
      oilTankSupports: 2,
      oilPipeBrackets: 2,
    },
  });
}

function buildCooling(root, materials) {
  const assembly = "coolingAssembly";
  const part = factoryFor(root, assembly);
  const parts = [];
  const hoodInner = D.coolerRadius + 0.012;
  const hoodOuter = 0.46;
  const hoodZ0 = 3.15;
  const hoodZ1 = 4.75;
  for (let i = 0; i < D.coolerCount; i++) {
    const angle = TAU * i / D.coolerCount + Math.PI / 8;
    const x = Math.cos(angle) * D.coolerCenterRadius;
    const y = Math.sin(angle) * D.coolerCenterRadius;
    parts.push(
      part(
        `coolerBody_${i + 1}`,
        "duct",
        cylinder(D.coolerRadius, D.coolerZ0, D.coolerZ1, 28, x, y),
      ),
      part(
        `coolerTopCap_${i + 1}`,
        "darkSteel",
        cylinder(0.41, D.coolerZ1, D.coolerZ1 + 0.12, 28, x, y),
      ),
      part(
        `coolerHood_${i + 1}`,
        "duct",
        ring(hoodInner, hoodOuter, hoodZ0, hoodZ1, 32, x, y),
      ),
      part(
        `coolerLowerFlange_${i + 1}`,
        "steel",
        ring(D.coolerRadius + 0.008, hoodOuter + 0.02, hoodZ0 - 0.08, hoodZ0, 32, x, y),
      ),
      part(
        `coolerUpperFlange_${i + 1}`,
        "steel",
        ring(D.coolerRadius + 0.008, hoodOuter + 0.02, hoodZ1, hoodZ1 + 0.08, 32, x, y),
      ),
      part(
        `coolerDuct_${i + 1}`,
        "duct",
        radialCoolerDuct(
          D.statorHousingOuter,
          D.coolerCenterRadius,
          hoodOuter,
          0.46,
          hoodZ0 + 0.01,
          hoodZ1 - 0.01,
          angle,
        ),
      ),
      part(
        `coolerPedestal_${i + 1}`,
        "steel",
        radialBox(
          D.coolerCenterRadius - 0.21,
          D.coolerCenterRadius + 0.21,
          0.48,
          D.foundationHeight + 0.1,
          D.coolerZ0,
          angle,
        ),
      ),
    );
  }

  return makeAssembly(root, assembly, parts, materials, {
    explode: [0, 0, 5.5],
    stage: 0,
    labelAnchor: [0, 4.55, -5.05],
    description: ASSEMBLY_LABELS[assembly][1],
    counts: {
      coolers: D.coolerCount,
      coolerHoods: D.coolerCount,
      supportPedestals: D.coolerCount,
    },
  });
}

function buildExcitation(root, materials) {
  const assembly = "excitationAndLeads";
  const part = factoryFor(root, assembly);
  const terminalAngle = -Math.PI / 2;
  const terminalRadius = 5.16;
  const x = Math.cos(terminalAngle) * terminalRadius;
  const y = Math.sin(terminalAngle) * terminalRadius;
  const parts = [
    part(
      "terminalEnclosure",
      "terminal",
      radialBox(4.8, 5.55, 1.14, 0.9, 2.2, terminalAngle),
    ),
    part(
      "terminalBaseFrame",
      "darkSteel",
      radialBox(4.72, 5.62, 1.3, 0.62, 0.9, terminalAngle),
    ),
    part(
      "neutralBus",
      "copper",
      cylinder(0.075, 2.2, 3.08, 12, x + 0.38, y),
    ),
  ];

  for (let i = 0; i < 4; i++) {
    const angle = terminalAngle + (i - 1.5) * 0.12;
    parts.push(
      part(
        `terminalSupport_${i + 1}`,
        "steel",
        radialBox(
          terminalRadius - 0.12,
          terminalRadius + 0.12,
          0.17,
          D.foundationHeight + 0.1,
          0.62,
          angle,
        ),
      ),
    );
  }

  for (let lead = 0; lead < 3; lead++) {
    const offset = (lead - 1) * 0.19;
    const startAngle = terminalAngle + offset / 4.0;
    const endAngle = terminalAngle + offset / 5.2;
    const path = [
      [4.08 * Math.cos(startAngle), 4.08 * Math.sin(startAngle), 4.92],
      [4.42 * Math.cos(startAngle), 4.42 * Math.sin(startAngle), 4.2],
      [4.75 * Math.cos(endAngle), 4.75 * Math.sin(endAngle), 3.28],
      [
        (terminalRadius + offset) * Math.cos(endAngle),
        (terminalRadius + offset) * Math.sin(endAngle),
        2.2,
      ],
    ];
    parts.push(
      part(
        `phaseLead_${String.fromCharCode(65 + lead)}`,
        "copper",
        tubeAlong(path, circularProfile(0.052, 10), { up: [0, 0, 1], cap: true }),
      ),
      part(
        `leadClamp_${lead + 1}`,
        "darkSteel",
        boxAt(
          4.25 * Math.cos(startAngle),
          4.25 * Math.sin(startAngle),
          4.06,
          0.17,
          0.17,
          4.2,
        ),
      ),
    );
  }

  return makeAssembly(root, assembly, parts, materials, {
    explode: [4.8, 0, 0],
    stage: 0,
    labelAnchor: [x, 2.1, y],
    description: ASSEMBLY_LABELS[assembly][1],
    counts: { phaseLeads: 3, neutralLeads: 1 },
  });
}

export function createGeneratorModel({
  rootName = "meizhouGenerator",
  materials = createAssemblyMaterials(),
} = {}) {
  const root = new Group();
  root.name = rootName;
  root.userData = {
    unit: "m",
    authoringAxes: "Z-up in MeshData; emitted Three.js axes are Y-up",
    renderAxes: "+X right, +Y up, +Z toward default viewer",
    proportions: "reference-proportioned, not manufacturing dimensions",
  };

  root.add(
    buildFoundation(root.name, materials.foundationAssembly),
    buildLowerFrame(root.name, materials.lowerFrameAssembly),
    buildThrustBearing(root.name, materials.thrustBearingAssembly),
    buildStatorHousing(root.name, materials.statorHousingAssembly),
    buildStatorActive(root.name, materials.statorActiveAssembly),
    buildRotor(root.name, materials.rotorAssembly),
    buildUpperFrame(root.name, materials.upperFrameAssembly),
    buildCooling(root.name, materials.coolingAssembly),
    buildExcitation(root.name, materials.excitationAndLeads),
  );

  root.updateMatrixWorld(true);
  return root;
}

export { MATERIAL_SLOTS };
