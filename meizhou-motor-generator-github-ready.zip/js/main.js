import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import {
  Exploder,
  Labels,
  Picker,
  RotorExploder,
  Section,
  Xray,
} from "../vendor/explode.js?v=6";
import { createGeneratorModel } from "./generator-model.js?v=6";
import { ASSEMBLY_LABELS, MODEL_BOUNDS, TEACHING_DATA } from "./contracts.js";

const FLOW_META = Object.freeze({
  generation: Object.freeze([
    {
      assembly: "lowerFrameAssembly",
      detail: "机组能量来自水体势能；本灰模不包含水泵水轮机过流部件。",
    },
    {
      assembly: "lowerFrameAssembly",
      detail: "水头在流道中转换为压力能与动能；流道和转轮未建模。",
    },
    {
      assembly: "lowerFrameAssembly",
      detail: "转轮把水流能量转换为机械能；这里只表达与主轴连接的概念关系。",
    },
    {
      assembly: "rotorAssembly",
      detail: "转轮通过主轴传递扭矩；模型中的主轴与转子同轴。",
    },
    {
      assembly: "rotorAssembly",
      detail: "转子励磁绕组建立磁场；励磁电源来自自并励路径的教学示意。",
    },
    {
      assembly: "statorActiveAssembly",
      detail: "旋转磁场在定子线棒中感应三相交流电动势；576 根线棒未逐根建模。",
    },
    {
      assembly: "excitationAndLeads",
      detail: "发电机出口开关是机端与主变之间的教学节点；本模型未伪造 GCB 实体。",
    },
    {
      assembly: "excitationAndLeads",
      detail: "主变是升压连接的教学节点；真实一次接线和设备布置须查批准图纸。",
    },
    {
      assembly: "excitationAndLeads",
      detail: "电能送入系统侧；真实运行状态、保护和接线以现场有效文件为准。",
    },
  ]),
  pumping: Object.freeze([
    {
      assembly: "excitationAndLeads",
      detail: "电网向机组侧提供电能；这里只表示稳态能量方向。",
    },
    {
      assembly: "excitationAndLeads",
      detail: "主变作为系统电压与机端电压之间的教学节点。",
    },
    {
      assembly: "excitationAndLeads",
      detail: "发电机出口开关连接机端与主变；未按真实柜体或一次接线建模。",
    },
    {
      assembly: "statorActiveAssembly",
      detail: "定子通入三相电流产生旋转磁场；端部绕组仅作分组示意。",
    },
    {
      assembly: "rotorAssembly",
      detail: "转子在励磁磁场中同步跟随定子旋转磁场。",
    },
    {
      assembly: "rotorAssembly",
      detail: "电磁转矩经转子与主轴形成机械能。",
    },
    {
      assembly: "lowerFrameAssembly",
      detail: "主轴驱动水泵水轮机；水泵水轮机本体不在本灰模范围内。",
    },
    {
      assembly: "lowerFrameAssembly",
      detail: "机组按泵工况运行；SFC/BTB 等拖动配置仅在原理面板作教学提示。",
    },
  ]),
});

const PRINCIPLE_META = Object.freeze({
  GCB: {
    assembly: "excitationAndLeads",
    detail: "发电机出口开关教学节点，表达机端与主变的连接概念，不代表批准的一次接线。",
  },
  主变: {
    assembly: "excitationAndLeads",
    detail: "主变用于机端与系统电压等级之间的教学示意；真实设备未建模。",
  },
  电网: {
    assembly: "excitationAndLeads",
    detail: "电网是发电送出或抽水取电的系统侧概念节点。",
  },
  SFC: {
    assembly: "rotorAssembly",
    detail: "SFC 是抽水或调相拖动的教学概念；正常发电升速由水泵水轮机/调速器带动。",
  },
  BTB: {
    assembly: "rotorAssembly",
    detail: "BTB 仅作拖动原理的教学节点；实际配置和闭锁关系必须以现场文件为准。",
  },
  Q91: {
    assembly: "excitationAndLeads",
    detail: "Q91 是课件中的切换节点标记，不能据此推断现场设备用途或操作顺序。",
  },
  Q92: {
    assembly: "excitationAndLeads",
    detail: "Q92 是课件中的切换节点标记，编号和用途须与当前批准接线图核对。",
  },
  Q0: {
    assembly: "excitationAndLeads",
    detail: "Q0 是课件中的切换节点标记；本页不提供倒闸或切换步骤。",
  },
  中性点: {
    assembly: "excitationAndLeads",
    detail: "定子三相绕组的中性点教学节点；实际接地和测量配置以批准图纸为准。",
  },
  定子端电压: {
    assembly: "statorActiveAssembly",
    detail: "自并励路径的教学起点，取自定子端电压概念。",
  },
  励磁变: {
    assembly: "excitationAndLeads",
    detail: "励磁变是自并励路径中的电压变换节点；本模型未绘制真实柜体。",
  },
  可控硅整流: {
    assembly: "excitationAndLeads",
    detail: "可控硅整流把交流输入转换为转子励磁所需的直流概念量。",
  },
  "滑环 / 碳刷": {
    assembly: "rotorAssembly",
    detail: "滑环和碳刷是向旋转励磁绕组传递励磁电流的教学接口。",
  },
  转子励磁绕组: {
    assembly: "rotorAssembly",
    detail: "转子励磁绕组建立主磁场；模型只表达磁极和绕组所在空间。",
  },
});

const PRINCIPLE_DEFAULT =
  "点击图中节点查看教学说明；未建模设备不会被伪造成实体。";

const stage = document.querySelector("#stage");
const labelLayer = document.querySelector("#labels");
const loading = document.querySelector("#loading");
const loadingText = document.querySelector("#loadingText");
const controlPanel = document.querySelector("#controlPanel");
const explodeRange = document.querySelector("#explodeRange");
const explodeValue = document.querySelector("#explodeValue");
const explodeButton = document.querySelector("#explodeButton");
const rotorSupportToggle = document.querySelector("#rotorSupportToggle");
const rotorYokeToggle = document.querySelector("#rotorYokeToggle");
const rotorPoleToggle = document.querySelector("#rotorPoleToggle");
const showAllRotor = document.querySelector("#showAllRotor");
const rotorExplodeRange = document.querySelector("#rotorExplodeRange");
const rotorExplodeValue = document.querySelector("#rotorExplodeValue");
const rotorExplodeReset = document.querySelector("#rotorExplodeReset");
const focusRotor = document.querySelector("#focusRotor");
const resetView = document.querySelector("#resetView");
const teachingPanel = document.querySelector("#teachingPanel");
const teachingNote = document.querySelector("#teachingNote");
const modeTabs = [...document.querySelectorAll(".mode-tab")];
const energyView = document.querySelector("#energyView");
const principleView = document.querySelector("#principleView");
const flowTitle = document.querySelector("#flowTitle");
const energyChain = document.querySelector("#energyChain");
const flowPlay = document.querySelector("#flowPlay");
const flowReset = document.querySelector("#flowReset");
const flowDetail = document.querySelector("#flowDetail");
const principleDetail = document.querySelector("#principleDetail");
const monitorGrid = document.querySelector("#monitorGrid");
const sourceNote = document.querySelector(".source-note");
const safetyNote = document.querySelector("#safetyNote");
const sectionToggle = document.querySelector("#sectionToggle");
const sectionRange = document.querySelector("#sectionRange");
const sectionValue = document.querySelector("#sectionValue");
const xrayToggle = document.querySelector("#xrayToggle");
const selectionState = document.querySelector("#selectionState");
const assemblyName = document.querySelector("#assemblyName");
const assemblyDescription = document.querySelector("#assemblyDescription");
const assemblyStats = document.querySelector("#assemblyStats");
const envelopeValue = document.querySelector("#envelopeValue");
const meshCount = document.querySelector("#meshCount");

const demo = (window.__generatorDemo = {
  ready: false,
  error: null,
  explode: 0,
  rotorExplode: 0,
  rotorStructure: {
    support: true,
    yoke: true,
    pole: true,
  },
  section: true,
  xray: false,
  focus: null,
});

controlPanel.open = !window.matchMedia("(max-width: 760px)").matches;
teachingPanel.open = false;

try {
  boot();
} catch (error) {
  demo.error = error instanceof Error ? error.message : String(error);
  loading?.classList.add("is-error");
  if (loadingText) loadingText.textContent = "模型加载失败，请查看控制台。";
  console.error(error);
}

function boot() {
  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    powerPreference: "high-performance",
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(stage.clientWidth, stage.clientHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.18;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.localClippingEnabled = true;
  renderer.domElement.tabIndex = 0;
  renderer.domElement.setAttribute(
    "aria-label",
    "三维模型画布。拖动旋转，滚轮缩放，右键拖动平移。",
  );
  stage.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x111619);
  scene.fog = new THREE.Fog(0x111619, 34, 72);
  scene.environmentIntensity = 0.85;

  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  scene.environment = pmrem.fromScene(room, 0.04).texture;
  room.dispose();
  pmrem.dispose();

  const camera = new THREE.PerspectiveCamera(
    38,
    stage.clientWidth / stage.clientHeight,
    0.1,
    150,
  );
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.065;
  controls.minPolarAngle = 0.14;
  controls.maxPolarAngle = Math.PI * 0.49;
  controls.screenSpacePanning = true;
  controls.zoomToCursor = true;
  let cameraMove = null;
  controls.addEventListener("start", () => {
    cameraMove = null;
  });

  addLighting(scene);
  addGround(scene);

  const model = createGeneratorModel();
  scene.add(model);

  let meshTotal = 0;
  model.traverse((object) => {
    if (!object.isMesh) return;
    meshTotal += 1;
    object.castShadow = object.castShadow !== false;
    object.receiveShadow = true;
  });
  meshCount.textContent = `${meshTotal} meshes`;

  const assemblesByName = Object.fromEntries(
    model.children.map((assembly) => [assembly.name, assembly]),
  );
  const exploder = new Exploder(model);
  const housingSection = new Section(
    assemblesByName.statorHousingAssembly,
    [0, 0, -1],
  );
  const statorSection = new Section(
    assemblesByName.statorActiveAssembly,
    [0, 0, -1],
  );
  const lowerFrameSection = new Section(
    assemblesByName.lowerFrameAssembly,
    [0, 0, -1],
  );
  const upperFrameSection = new Section(
    assemblesByName.upperFrameAssembly,
    [0, 0, -1],
  );
  const rotorExploder = new RotorExploder(assemblesByName.rotorAssembly);
  const rotorSection = new Section(
    assemblesByName.rotorAssembly,
    [0, 0, -1],
  );
  const housingXray = new Xray(assemblesByName.statorHousingAssembly);
  const defaultSectionZ = 2.0;
  const sectionCuts = [
    housingSection,
    statorSection,
    lowerFrameSection,
    upperFrameSection,
    rotorSection,
  ];
  for (const cut of sectionCuts) cut.set(defaultSectionZ);

  const labels = new Labels(labelLayer, camera, renderer.domElement);
  const labelItems = new Map();
  for (const assembly of model.children) {
    if (assembly.name === "rotorAssembly") {
      for (const name of [
        "rotorSupportAssembly",
        "rotorYokeAssembly",
        "rotorPoleAssembly",
      ]) {
        const group = assembly.getObjectByName(name);
        const anchor =
          name === "rotorSupportAssembly"
            ? [0.8, 5.92, -1.5]
            : name === "rotorYokeAssembly"
              ? [2.45, 5.95, -1.55]
              : [2.65, 5.35, -1.35];
        labelItems.set(group, labels.add(group, group.userData.title, { anchor }));
      }
      continue;
    }
    const [title] = ASSEMBLY_LABELS[assembly.name];
    const item = labels.add(assembly, title, {
      anchor: assembly.userData.labelAnchor ?? [0, 0, 0],
    });
    labelItems.set(assembly, item);
  }

  let selectedAssembly = null;
  let hoveredAssembly = null;
  let teachingHighlightedAssembly = null;
  let teachingMode = "generation";
  let flowIndex = -1;
  let flowTimer = 0;
  let flowPlaying = false;
  let activePrinciple = null;
  demo.teaching = {
    mode: teachingMode,
    index: flowIndex,
    principle: null,
    playing: false,
    highlightedAssembly: null,
  };

  const picker = new Picker(renderer.domElement, camera, model.children, {
    onHover(assembly) {
      hoveredAssembly = assembly;
      focusLabel(assembly);
      showAssembly(assembly ?? selectedAssembly ?? teachingHighlightedAssembly);
    },
    onPick(assembly) {
      setSelectedAssembly(assembly === selectedAssembly ? null : assembly);
      showAssembly(selectedAssembly ?? hoveredAssembly ?? teachingHighlightedAssembly);
    },
  });

  renderer.domElement.addEventListener("pointerleave", () => {
    if (picker.hot) picker.highlight(picker.hot, false);
    picker.hot = null;
    hoveredAssembly = null;
    renderer.domElement.style.cursor = "";
    focusLabel(null);
    showAssembly(selectedAssembly ?? teachingHighlightedAssembly);
  });

  function setSelectedAssembly(assembly) {
    if (selectedAssembly === assembly) return;
    if (selectedAssembly) picker.highlight(selectedAssembly, false);
    selectedAssembly = assembly;
    if (selectedAssembly) picker.highlight(selectedAssembly, true);
    demo.selectedAssembly = selectedAssembly?.name ?? null;
  }

  function setTeachingHighlight(assembly) {
    if (teachingHighlightedAssembly === assembly) return;
    if (teachingHighlightedAssembly) {
      picker.highlight(teachingHighlightedAssembly, false);
    }
    teachingHighlightedAssembly = assembly;
    if (teachingHighlightedAssembly) {
      picker.highlight(teachingHighlightedAssembly, true);
    }
    demo.teaching.highlightedAssembly = teachingHighlightedAssembly?.name ?? null;
  }

  const rotorGroups = {
    support: assemblesByName.rotorAssembly.getObjectByName("rotorSupportAssembly"),
    yoke: assemblesByName.rotorAssembly.getObjectByName("rotorYokeAssembly"),
    pole: assemblesByName.rotorAssembly.getObjectByName("rotorPoleAssembly"),
  };
  const rotorGroupToggles = {
    support: rotorSupportToggle,
    yoke: rotorYokeToggle,
    pole: rotorPoleToggle,
  };

  function belongsTo(assembly, root) {
    for (let node = assembly; node; node = node.parent) {
      if (node === root) return true;
    }
    return false;
  }

  function clearHiddenSelection(root) {
    if (belongsTo(selectedAssembly, root)) setSelectedAssembly(null);
    if (belongsTo(teachingHighlightedAssembly, root)) setTeachingHighlight(null);
    if (belongsTo(hoveredAssembly, root)) {
      if (picker.hot) picker.highlight(picker.hot, false);
      picker.hot = null;
      hoveredAssembly = null;
      renderer.domElement.style.cursor = "";
    }
    focusLabel(null);
    showAssembly(selectedAssembly ?? teachingHighlightedAssembly);
  }

  function setRotorGroupVisible(key, visible) {
    const group = rotorGroups[key];
    group.visible = Boolean(visible);
    rotorGroupToggles[key].checked = group.visible;
    demo.rotorStructure[key] = group.visible;
    if (!group.visible) clearHiddenSelection(group);
  }

  for (const [key, toggle] of Object.entries(rotorGroupToggles)) {
    toggle.addEventListener("change", () => {
      setRotorGroupVisible(key, toggle.checked);
    });
  }
  showAllRotor.addEventListener("click", () => {
    for (const key of Object.keys(rotorGroups)) setRotorGroupVisible(key, true);
  });

  function pauseFlow() {
    window.clearInterval(flowTimer);
    flowTimer = 0;
    flowPlaying = false;
    demo.teaching.playing = false;
    flowPlay.textContent = "播放路径";
  }

  function clearFlowSelection() {
    flowIndex = -1;
    demo.teaching.index = flowIndex;
    for (const button of energyChain.querySelectorAll("button")) {
      button.classList.remove("is-active");
      button.removeAttribute("aria-current");
    }
    if (flowDetail) {
      flowDetail.textContent =
        "点击节点查看对应装配；播放只按顺序高亮，不表示真实操作步骤。";
    }
    setTeachingHighlight(null);
  }

  function selectFlowStep(index) {
    const steps = FLOW_META[teachingMode]
      ? TEACHING_DATA.energy[teachingMode]
      : null;
    if (!steps) return;
    if (index < 0 || index >= steps.length) {
      clearFlowSelection();
      return;
    }

    flowIndex = index;
    const buttons = [...energyChain.querySelectorAll("button")];
    buttons.forEach((button, buttonIndex) => {
      const active = buttonIndex === index;
      button.classList.toggle("is-active", active);
      if (active) button.setAttribute("aria-current", "step");
      else button.removeAttribute("aria-current");
    });

    const meta = FLOW_META[teachingMode][index];
    flowDetail.textContent = `${index + 1}. ${steps[index]}：${meta.detail}`;
    setTeachingHighlight(assemblesByName[meta.assembly] ?? null);
    demo.teaching.index = flowIndex;
  }

  function renderFlow() {
    pauseFlow();
    const steps = TEACHING_DATA.energy[teachingMode];
    flowTitle.textContent = teachingMode === "generation" ? "发电能量链" : "抽水能量链";
    const fragment = document.createDocumentFragment();
    steps.forEach((step, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.step = String(index + 1).padStart(2, "0");
      button.textContent = step;
      button.addEventListener("click", () => {
        pauseFlow();
        selectFlowStep(index);
      });
      fragment.append(button);
    });
    energyChain.replaceChildren(fragment);
    clearFlowSelection();
  }

  function startFlow() {
    if (flowPlaying || teachingMode === "principle") return;
    const steps = TEACHING_DATA.energy[teachingMode];
    if (!steps.length) return;
    if (flowIndex < 0 || flowIndex >= steps.length - 1) {
      selectFlowStep(0);
    } else {
      selectFlowStep(flowIndex + 1);
    }
    flowPlaying = true;
    demo.teaching.playing = true;
    flowPlay.textContent = "暂停路径";
    if (flowIndex >= steps.length - 1) {
      pauseFlow();
      return;
    }
    flowTimer = window.setInterval(() => {
      if (flowIndex >= steps.length - 1) {
        pauseFlow();
        return;
      }
      selectFlowStep(flowIndex + 1);
      if (flowIndex >= steps.length - 1) pauseFlow();
    }, 1150);
  }

  function clearPrincipleSelection() {
    activePrinciple = null;
    demo.teaching.principle = null;
    for (const button of document.querySelectorAll("[data-principle]")) {
      button.classList.remove("is-active");
    }
    principleDetail.textContent = PRINCIPLE_DEFAULT;
  }

  function selectPrinciple(button) {
    const name = button.dataset.principle;
    if (activePrinciple === name) {
      clearPrincipleSelection();
      setTeachingHighlight(null);
      return;
    }
    for (const node of document.querySelectorAll("[data-principle]")) {
      node.classList.toggle("is-active", node === button);
    }
    activePrinciple = name;
    const meta = PRINCIPLE_META[name];
    principleDetail.textContent = meta?.detail ?? "该节点的教学说明尚未配置。";
    setTeachingHighlight(
      meta?.assembly ? (assemblesByName[meta.assembly] ?? null) : null,
    );
    demo.teaching.principle = name;
  }

  function setTeachingMode(mode) {
    setRotorExplode(0);
    pauseFlow();
    setTeachingHighlight(null);
    clearFlowSelection();
    clearPrincipleSelection();
    teachingMode = mode;
    demo.teaching.mode = teachingMode;

    for (const tab of modeTabs) {
      const active = tab.dataset.mode === teachingMode;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", String(active));
      tab.tabIndex = active ? 0 : -1;
    }

    const isPrinciple = teachingMode === "principle";
    energyView.hidden = isPrinciple;
    principleView.hidden = !isPrinciple;
    if (isPrinciple) {
      teachingNote.textContent =
        "原理示意：主回路节点只用于认知；未建模设备不会被伪装成实体。";
    } else if (teachingMode === "pumping") {
      teachingNote.textContent =
        "抽水工况：电网输入电能，机组作为同步电动机驱动水泵水轮机。仅演示能量方向。";
      renderFlow();
    } else {
      teachingNote.textContent =
        "发电工况：水流能量经水泵水轮机、主轴和发电电动机转换为电能。仅演示能量方向。";
      renderFlow();
    }
  }

  for (const tab of modeTabs) {
    tab.addEventListener("click", () => setTeachingMode(tab.dataset.mode));
  }
  flowPlay.addEventListener("click", () => {
    if (flowPlaying) pauseFlow();
    else startFlow();
  });
  flowReset.addEventListener("click", () => {
    pauseFlow();
    clearFlowSelection();
  });
  principleView.addEventListener("click", (event) => {
    const button = event.target.closest("[data-principle]");
    if (button) selectPrinciple(button);
  });
  window.addEventListener("blur", pauseFlow);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) pauseFlow();
  });

  renderTeachingMonitor();
  setTeachingMode("generation");

  function focusLabel(assembly) {
    for (const item of labelItems.values()) item.focus = false;
    const labelAssembly =
      assembly?.name?.startsWith("pole_")
        ? rotorGroups.pole
        : assembly;
    const focused = labelAssembly && labelItems.get(labelAssembly);
    if (focused) focused.focus = true;
  }

  function showAssembly(assembly) {
    if (!assembly) {
      selectionState.textContent = "整体装配";
      assemblyName.textContent = "同类 300 MW 级发电电动机";
      assemblyDescription.textContent =
        "九个顶层装配。拖动旋转、滚轮缩放；悬停或点击设备查看名称与结构关系。";
      assemblyStats.textContent = "原点：基础底面中心";
      return;
    }
    const [fallbackTitle, fallbackDescription] =
      ASSEMBLY_LABELS[assembly.name] ?? [];
    const title = assembly.userData.title ?? fallbackTitle ?? assembly.name;
    const description =
      assembly.userData.description ?? fallbackDescription ?? "教学示意装配。";
    const count = assembly.userData.counts ?? {};
    const countText = Object.entries(count)
      .filter(([, value]) => typeof value === "number")
      .map(([key, value]) => `${key} ${value}`)
      .join(" · ");
    selectionState.textContent =
      hoveredAssembly === assembly
        ? "当前指向"
        : selectedAssembly === assembly
          ? "已选中装配"
          : teachingHighlightedAssembly === assembly
            ? "教学路径"
            : "装配信息";
    assemblyName.textContent = title;
    assemblyDescription.textContent = description;
    assemblyStats.textContent = countText
      ? `${assembly.userData.localParts.length} 个零件 · ${countText}`
      : `${assembly.userData.localParts.length} 个语义零件`;
  }

  function setSoloAssembly(assembly = null) {
    for (const child of model.children) {
      child.visible = !assembly || child === assembly;
    }
    demo.isolatedAssembly = assembly?.name ?? null;
  }

  const [min, max] = [MODEL_BOUNDS.min, MODEL_BOUNDS.max];
  envelopeValue.textContent =
    `边界 ${(max[0] - min[0]).toFixed(2)} × ` +
    `${(max[1] - min[1]).toFixed(2)} × ${(max[2] - min[2]).toFixed(2)} m`;

  function setExplode(value, refit = false) {
    const percent = THREE.MathUtils.clamp(Number(value), 0, 100);
    if (percent > 0 && demo.rotorExplode > 0) setRotorExplode(0);
    demo.explode = percent;
    explodeRange.value = String(Math.round(percent));
    explodeValue.textContent = `${Math.round(percent)}%`;
    exploder.set(percent / 100);
    explodeButton.textContent = percent > 0 ? "合拢整机" : "一键分解";
    explodeButton.setAttribute("aria-pressed", String(percent > 0));
    if (refit) fitView();
  }

  explodeRange.addEventListener("input", () => setExplode(explodeRange.value));
  explodeButton.addEventListener("click", () => {
    setExplode(demo.explode > 0 ? 0 : 100, true);
  });

  function setRotorExplode(value) {
    const percent = THREE.MathUtils.clamp(Number(value), 0, 100);
    if (percent > 0 && demo.explode > 0) setExplode(0);
    demo.rotorExplode = percent;
    rotorExplodeRange.value = String(Math.round(percent));
    rotorExplodeValue.textContent = `${Math.round(percent)}%`;
    rotorExploder.set(percent / 100);
  }

  rotorExplodeRange.addEventListener("input", () => {
    setRotorExplode(rotorExplodeRange.value);
  });
  rotorExplodeReset.addEventListener("click", () => setRotorExplode(0));

  function applySection() {
    const enabled = sectionToggle.checked;
    demo.section = enabled;
    sectionRange.disabled = !enabled;
    const z = Number(sectionRange.value);
    sectionValue.textContent = `+${z.toFixed(1)} m`;
    for (const cut of sectionCuts) cut.set(enabled ? z : null);
  }

  sectionToggle.addEventListener("change", applySection);
  sectionRange.addEventListener("input", applySection);

  xrayToggle.addEventListener("change", () => {
    demo.xray = xrayToggle.checked;
    housingXray.set(demo.xray, 0.16);
  });

  let fittedDistance = 0;
  function fitView(subject = model, direction = new THREE.Vector3(0.18, 0.16, 1)) {
    cameraMove = null;
    const bounds = new THREE.Box3().setFromObject(subject);
    const sphere = bounds.getBoundingSphere(new THREE.Sphere());
    const verticalFov = THREE.MathUtils.degToRad(camera.fov);
    const horizontalFov =
      2 * Math.atan(Math.tan(verticalFov * 0.5) * camera.aspect);
    const limitingFov = Math.min(verticalFov, horizontalFov);
    const distance = (sphere.radius / Math.sin(limitingFov * 0.5)) * 1.08;
    direction.normalize();
    const target = sphere.center.clone();
    target.x += 0.62;

    controls.target.copy(target);
    camera.position.copy(controls.target).addScaledVector(direction, distance);
    camera.near = Math.max(0.08, distance / 900);
    camera.far = Math.max(120, distance * 8);
    camera.updateProjectionMatrix();
    controls.minDistance = Math.max(3, sphere.radius * 0.38);
    controls.maxDistance = distance * 3.2;
    fittedDistance = distance;
    demo.fitDistance = distance;
    scene.fog.near = distance * 1.45;
    scene.fog.far = distance * 2.9;
    controls.update();
  }

  focusRotor.addEventListener("click", () => {
    pauseFlow();
    clearFlowSelection();
    clearPrincipleSelection();
    setSelectedAssembly(null);
    setTeachingHighlight(null);
    hoveredAssembly = null;
    setExplode(0);
    setRotorExplode(0);
    sectionToggle.checked = true;
    sectionRange.value = String(defaultSectionZ);
    applySection();

    const rotor = assemblesByName.rotorAssembly;
    showAssembly(rotor);
    focusLabel(rotorGroups.pole);
    fitView(rotor, new THREE.Vector3(0.7, 0.5, 1));
    demo.focus = "rotor";
  });

  resetView.addEventListener("click", () => {
    pauseFlow();
    clearFlowSelection();
    clearPrincipleSelection();
    setSelectedAssembly(null);
    setTeachingHighlight(null);
    hoveredAssembly = null;
    focusLabel(null);
    setExplode(0);
    setRotorExplode(0);
    for (const key of Object.keys(rotorGroups)) setRotorGroupVisible(key, true);
    sectionToggle.checked = true;
    sectionRange.value = String(defaultSectionZ);
    xrayToggle.checked = false;
    demo.xray = false;
    housingXray.set(false);
    applySection();
    setSoloAssembly(null);
    showAssembly(null);
    demo.focus = null;
    fitView();
  });

  window.addEventListener("resize", () => {
    const width = stage.clientWidth;
    const height = stage.clientHeight;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
  });

  fitView();
  setExplode(0);
  applySection();
  showAssembly(null);

  let firstFrame = true;
  function animate() {
    requestAnimationFrame(animate);
    if (cameraMove) {
      const progress = Math.min(
        1,
        (performance.now() - cameraMove.startedAt) / cameraMove.duration,
      );
      const eased = progress * progress * (3 - 2 * progress);
      camera.position.lerpVectors(
        cameraMove.fromPosition,
        cameraMove.toPosition,
        eased,
      );
      controls.target.lerpVectors(
        cameraMove.fromTarget,
        cameraMove.toTarget,
        eased,
      );
      if (progress === 1) cameraMove = null;
    }
    controls.update();
    labels.update();
    renderer.render(scene, camera);
    if (firstFrame) {
      firstFrame = false;
      loading.classList.add("is-hidden");
      demo.ready = true;
      console.info(
        `[generator] ready · ${meshTotal} meshes · fit ${fittedDistance.toFixed(2)} m`,
      );
    }
  }
  animate();

  Object.assign(demo, {
    scene,
    camera,
    renderer,
    controls,
    model,
    exploder,
    rotorExploder,
    housingSection,
    statorSection,
    rotorSection,
    housingXray,
    labels,
    picker,
    setExplode,
    setRotorExplode,
    setRotorGroupVisible,
    fitView,
    getState: () => ({
      explode: demo.explode,
      rotorExplode: demo.rotorExplode,
      rotorStructure: { ...demo.rotorStructure },
      section: demo.section,
      rotorSection: rotorSection.plane.constant,
      xray: demo.xray,
      selectedAssembly: demo.selectedAssembly ?? null,
      teaching: { ...demo.teaching },
      cameraDistance: camera.position.distanceTo(controls.target),
      target: controls.target.toArray(),
    }),
  });
}

function renderTeachingMonitor() {
  sourceNote.textContent = TEACHING_DATA.sourceNote;
  safetyNote.textContent = TEACHING_DATA.safety;

  const table = document.createElement("table");
  const head = table.createTHead().insertRow();
  for (const label of ["测点", "报警 ℃ / 范围", "停机 ℃"]) {
    const cell = document.createElement("th");
    cell.textContent = label;
    head.append(cell);
  }

  const body = table.createTBody();
  for (const [name, alarm, trip] of TEACHING_DATA.temperatureLimits) {
    const row = body.insertRow();
    for (const value of [name, alarm, trip ?? "—"]) {
      const cell = row.insertCell();
      cell.textContent = String(value);
    }
  }
  const voltageRow = body.insertRow();
  for (const value of [
    "定子端电压",
    `${TEACHING_DATA.voltage.minKv.toFixed(1)}–${TEACHING_DATA.voltage.maxKv.toFixed(1)} kV`,
    "—",
  ]) {
    const cell = voltageRow.insertCell();
    cell.textContent = value;
  }
  monitorGrid.replaceChildren(table);
}

function addLighting(scene) {
  const hemisphere = new THREE.HemisphereLight(0xdde7ea, 0x20272a, 1.7);
  scene.add(hemisphere);

  const key = new THREE.DirectionalLight(0xfff4e8, 3.2);
  key.position.set(10, 16, 12);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.near = 0.5;
  key.shadow.camera.far = 42;
  key.shadow.camera.left = -15;
  key.shadow.camera.right = 15;
  key.shadow.camera.top = 18;
  key.shadow.camera.bottom = -8;
  key.shadow.bias = -0.0002;
  key.shadow.normalBias = 0.018;
  scene.add(key);

  const rim = new THREE.DirectionalLight(0xb9d1da, 1.45);
  rim.position.set(-12, 8, -10);
  scene.add(rim);
}

function addGround(scene) {
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(46, 46),
    new THREE.MeshStandardMaterial({
      color: 0x252c2f,
      roughness: 0.96,
      metalness: 0.02,
    }),
  );
  ground.name = "referenceGround";
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.018;
  ground.receiveShadow = true;
  scene.add(ground);

  const grid = new THREE.GridHelper(46, 46, 0x607176, 0x394448);
  grid.name = "meterGrid";
  grid.position.y = 0.006;
  grid.material.transparent = true;
  grid.material.opacity = 0.38;
  grid.material.depthWrite = false;
  scene.add(grid);

  const axes = new THREE.AxesHelper(2.4);
  axes.name = "coordinateAxes";
  axes.position.set(7.1, 0.035, 5.0);
  scene.add(axes);
}
