$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 4173
$url = "http://127.0.0.1:$port/"

$server = Start-Process `
  -FilePath "python" `
  -ArgumentList @("-m", "http.server", "$port", "--bind", "127.0.0.1") `
  -WorkingDirectory $projectRoot `
  -WindowStyle Hidden `
  -PassThru

try {
  Start-Sleep -Milliseconds 700
  Start-Process $url
  Write-Host "发电电动机灰模：$url"
  Write-Host "按 Enter 停止本地服务器。"
  [void](Read-Host)
}
finally {
  if (!$server.HasExited) {
    Stop-Process -Id $server.Id
  }
}
